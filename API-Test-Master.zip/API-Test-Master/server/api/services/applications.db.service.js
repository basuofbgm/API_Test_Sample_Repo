import { json } from "body-parser";

class ApplicationsDatabase {
    constructor() {
        this._data = [];
        this._counter = 0;

        this.insert({
            applicant_first_name: "John",
            applicant_last_name: "Doe",
            loan_amount: 400000,
        });
        this.insert({
            id: 10,
            applicant_first_name: "Mike",
            applicant_last_name: "Roster",
            loan_amount: 1000000,
        });
    }

    async all() {
        return this._data;
    }

    async byId(id) {

        var arrItems = this._data.find(arrItems => arrItems.id == id);

        return arrItems;
    }
    async removeArrItemId(id) {

        this._data.remove(arrItems => arrItems.id == id);

        return json({ message: 'User Record Successfuly deleted!' })

    }
    async insert(application) {
        const record = {
            id: this._counter,
            ...application,
        };

        this._counter += 1;
        this._data.push(record);

        return record;
    }
    async update(usrRecord) {
        var arrItems = this._data.find(arrItems => arrItems.id == usrRecord.id);

        this._data.update(arrItems);

        return json({ message: 'User Record Successfuly deleted!' });
    }
}

export default new ApplicationsDatabase();